import React, { Component } from "react";
import { Modal, Button, Typography } from "antd";

class AssignmetModal extends Component {
  state = { visible: false };

  showModal = () => {
    this.setState({
      visible: true
    });
  };

  handleOk = e => {
    console.log(e);
    this.setState({
      visible: false
    });
  };

  handleCancel = e => {
    console.log(e);
    this.setState({
      visible: false
    });
  };

  render() {
    const { title } = this.props;
    return (
      <div>
        <Button
          type="link"
          //   style={{ border: "none" }}
          onClick={this.showModal}
        >
          {title}
        </Button>
        <Modal
          title={title}
          visible={this.state.visible}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
        >
          <Typography.Text>
            Deep Learning Data Warehosue Design Analysis and alogorithms
            today is my hackothon in FSAD
          </Typography.Text>
          <br />
          <br />
          <Typography.Text>Last Date of Submission: 27-08-2019</Typography.Text>
          <div
            style={{
              display: "flex",
              justifyContent: "space-around",
              marginTop: 25
            }}
          >
            <Button style={{ marginRight: 10 }} icon="upload">
              Upload
            </Button>
            <Button icon="download">Download</Button>
          </div>
        </Modal>
      </div>
    );
  }
}

export default AssignmetModal;
