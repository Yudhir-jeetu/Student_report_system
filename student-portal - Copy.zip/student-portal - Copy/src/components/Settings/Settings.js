import React, { useState, useEffect } from "react";

const Settings = () => {
  // State for user details
  const [user, setUser] = useState({
    username: "",
    name: "",
    age: "",
    email: ""
  });

  // Load existing user details from localStorage when the component mounts
  useEffect(() => {
    const storedUser = {
      username: localStorage.getItem("username") || "",
      name: localStorage.getItem("name") || "",
      age: localStorage.getItem("age") || "",
      email: localStorage.getItem("email") || ""
    };
    setUser(storedUser);
  }, []);

  // Handle input changes
  const handleChange = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };

  // Save updated user details
  const handleSave = () => {
    localStorage.setItem("username", user.username);
    localStorage.setItem("name", user.name);
    localStorage.setItem("age", user.age);
    localStorage.setItem("email", user.email);

    alert("Profile updated successfully!");
  };

  return (
    <div style={{ maxWidth: "400px", margin: "50px auto", padding: "20px", background: "#222", color: "#fff", borderRadius: "10px" }}>
      <h2>Update Profile</h2>
      <label>Username:</label>
      <input type="text" name="username" value={user.username} onChange={handleChange} style={{ width: "100%", padding: "5px" }} />
      
      <label>Name:</label>
      <input type="text" name="name" value={user.name} onChange={handleChange} style={{ width: "100%", padding: "5px" }} />

      <label>Age:</label>
      <input type="number" name="age" value={user.age} onChange={handleChange} style={{ width: "100%", padding: "5px" }} />

      <label>Email:</label>
      <input type="email" name="email" value={user.email} onChange={handleChange} style={{ width: "100%", padding: "5px" }} />

      <button onClick={handleSave} style={{ marginTop: "10px", padding: "8px", background: "#72417e", color: "#fff", border: "none", cursor: "pointer" }}>
        Save Changes
      </button>
    </div>
  );
};

export default Settings;
