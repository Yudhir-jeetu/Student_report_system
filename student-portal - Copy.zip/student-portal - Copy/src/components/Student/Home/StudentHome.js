import React from "react";
import { Layout } from "antd";
import DashboardCard from "../../UI Components/Card/DashboardCard";
import StudentPageLayout from "../Layout/StudentPageLayout";

import StudentClasses from "../StudentHome.module.css";

const { Content } = Layout;

const StudentHome = () => {
  return (
    <StudentPageLayout menuSelect="1">
      <Content className={StudentClasses.dashboard}>
        <DashboardCard
          imageURL="/image.png"
          title="Attendance"
          link="/attendance"
        />
        <DashboardCard
          imageURL="/test.gif"
          title="Assignments"
          link="/assignments"
        />
        <DashboardCard
          imageURL="/setting.gif"
          title="Settings"
          link="/settings"
        />
      </Content>
    </StudentPageLayout>
  );
};

export default StudentHome;
