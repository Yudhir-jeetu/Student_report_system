import React, { Component } from "react";
import AttendanceCard from "../../UI Components/Calender/AttendanceCard";
import StudentPageLayout from "../Layout/StudentPageLayout";
import { Typography } from "antd";

class AttendancePage extends Component {
  render() {
    return (
      <StudentPageLayout menuSelect="2">
        <div style={{ marginTop: 20, overflow: 'scroll', width: '100%' }}>
          <Typography.Title 
            style={{ 
              textAlign: "center", 
              color: "rgba(0,0,0,0.6)", 
              fontWeight: "normal" 
            }}
          >
            Subject Wise Attendance Percent
          </Typography.Title>
          <div className="attendance-page">
            <AttendanceCard 
              subject="Deep Learning" 
              attendance={{ p: 88, a: 12 }} 
            />
            <AttendanceCard 
              subject="Data Warehousing" 
              attendance={{ p: 82, a: 18 }} 
            />
            <AttendanceCard 
              subject="Design Analysis" 
              attendance={{ p: 75, a: 25 }} 
            />
            <AttendanceCard 
              subject="Full Stack Dev" 
              attendance={{ p: 90, a: 10 }} 
            />
            <AttendanceCard 
              subject="Math Programming" 
              attendance={{ p: 70, a: 30 }} 
            />
            <AttendanceCard 
              subject="PCAP Programming" 
              attendance={{ p: 85, a: 15 }} 
            />
          </div>
        </div>
      </StudentPageLayout>
    );
  }
}

export default AttendancePage;