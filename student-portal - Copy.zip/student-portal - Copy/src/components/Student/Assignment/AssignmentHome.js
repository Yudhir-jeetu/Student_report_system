import React, { Component } from "react";
import { Divider } from "antd";
import StudentPageLayout from "../Layout/StudentPageLayout";
import AssignmentsTab from "../../UI Components/AssignmentsTab/AssignmentsTab";

const data = [
  {
    title: "Neural Network Implementation",
    desc: "Design and implement a basic neural network from scratch using Python to solve a classification problem."
  },
  {
    title: "CNN for Image Recognition",
    desc: "Build a convolutional neural network using TensorFlow/Keras to classify images from the CIFAR-10 dataset."
  },
  {
    title: "Data Warehouse Schema Design",
    desc: "Create a star schema for a retail business including fact tables and dimension tables with proper relationships."
  },
  {
    title: "ETL Process Implementation",
    desc: "Develop an ETL pipeline to extract data from multiple sources, transform it, and load it into a data warehouse."
  },
  {
    title: "System Design Documentation",
    desc: "Produce comprehensive design documentation for a proposed software solution including UML diagrams."
  },
  {
    title: "Algorithm Complexity Analysis",
    desc: "Analyze and compare the time complexity of different sorting algorithms with empirical data."
  }
];

class AssignmentHome extends Component {
  state = {
    tabData: [
      "Deep Learning", 
      "Data Warehousing", 
      "Design Analysis", 
      "Full Stack Development", 
      "Mathematical Programming", 
      "PCAP Programming"
    ]
  };
  
  render() {
    return (
      <StudentPageLayout menuSelect="3">
        <div
          style={{
            display: "flex",
            width: "100%",
            justifyContent: "space-around",
            overflow: "scroll",
            flexWrap: "wrap"
          }}
        >
          <AssignmentsTab
            title="On-Going"
            data={data}
            tabData={this.state.tabData}
          />
          {window.innerWidth === 650 ? <Divider /> : null}
          <AssignmentsTab
            data={data}
            tabData={this.state.tabData}
            isCompleted={true}
            title="Completed"
          />
        </div>
      </StudentPageLayout>
    );
  }
}

export default AssignmentHome;